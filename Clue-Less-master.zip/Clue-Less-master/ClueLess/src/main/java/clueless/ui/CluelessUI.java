package clueless.ui;

import clueless.gamelogic.Player;

/**
 * Just a placeholder for now.
 * 
 * @author matthewsobocinski
 */
/*public class CluelessUI {
   public static void main(String[] args) {
	   HomeScreen start = new HomeScreen();
   }
}*/