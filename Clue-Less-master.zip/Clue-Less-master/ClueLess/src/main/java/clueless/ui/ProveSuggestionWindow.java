package clueless.ui;

/**
 * Class for players' suggestion proof window UI
 * 
 * @author erinsmedley
 *
 */
public class ProveSuggestionWindow {

	public ProveSuggestionWindow() {
		
	}
}
