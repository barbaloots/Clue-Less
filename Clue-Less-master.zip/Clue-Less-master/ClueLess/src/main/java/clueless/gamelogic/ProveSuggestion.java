package clueless.gamelogic;

/**
 * Class for players to prove a suggestion
 * 
 * @author erinsmedley
 *
 */
public class ProveSuggestion {

}
