package clueless;

/**
 *
 * 
 */
public class ServerConnection {
   
}
