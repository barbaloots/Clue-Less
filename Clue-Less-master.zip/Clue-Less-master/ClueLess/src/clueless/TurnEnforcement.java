package clueless;

/**
 *
 * @author drobi
 */
public class TurnEnforcement {
   
}
