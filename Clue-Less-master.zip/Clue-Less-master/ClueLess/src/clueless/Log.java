package clueless;

/**
 *
 * @author drobi
 */
public class Log {
   
}
