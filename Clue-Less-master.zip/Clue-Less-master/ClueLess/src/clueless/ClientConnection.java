package clueless;

/**
 *
 * 
 */
public class ClientConnection {
   
}
