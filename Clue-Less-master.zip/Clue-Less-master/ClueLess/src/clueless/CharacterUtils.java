package clueless;

/**
 *
 * @author drobi
 */
public class CharacterUtils {
   
}
