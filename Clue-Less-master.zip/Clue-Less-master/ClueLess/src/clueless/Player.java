package clueless;

/**
 * The player class handles all functionality related to a player.
 * 
 */
public class Player {
   
}
