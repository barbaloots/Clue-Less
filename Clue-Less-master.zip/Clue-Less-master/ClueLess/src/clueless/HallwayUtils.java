package clueless;

/**
 *
 * @author drobi
 */
public class HallwayUtils {
   
}
