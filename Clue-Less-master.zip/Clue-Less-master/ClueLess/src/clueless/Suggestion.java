package clueless;

/**
 * The suggestion class handles all functionality related to making a suggestion.
 * 
 */
public class Suggestion {
   
}
