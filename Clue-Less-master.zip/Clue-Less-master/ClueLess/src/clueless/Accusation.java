package clueless;

/**
 * The accusation class handles all functionality related to making an accusation. 
 *
 */
public class Accusation {
   
}
